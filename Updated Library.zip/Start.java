import Frames.*;
public class Start {
    public static void main(String[] args) {
        //new BooksPage();
        //new UserPage();
        //new LogIn().setVisible(true);;
        //new Register().setVisible(true);;
        new Ohara1();
        //new Home("userName");
        //new UserDashboard();
        //new AdminLogin().setVisible(true);
        
    }
    
}
